const Components_vue_vue_type_style_index_0_scoped_bf4ccf1f_lang = ".n-card[data-v-bf4ccf1f]{max-height:140px;max-width:140px}.n-image[data-v-bf4ccf1f]{height:80px}.n-gradient-text[data-v-bf4ccf1f],.n-image[data-v-bf4ccf1f]{display:flex;justify-content:center}.n-gradient-text[data-v-bf4ccf1f]{align-items:center}.nav-box-son-text[data-v-bf4ccf1f]{display:flex;font-size:20px;font-weight:700;text-align:center}.nav-box-son-url[data-v-bf4ccf1f]{text-decoration:none}.nav-box[data-v-bf4ccf1f]{display:flex;flex-wrap:wrap;width:700px}.nav-box .nav-box-son[data-v-bf4ccf1f]{box-sizing:border-box;flex-basis:25%;padding:5px}";

const InputSearch_vue_vue_type_style_index_0_scoped_8231a1c9_lang = ".n-image[data-v-8231a1c9]{height:32px;width:32px}.nav-search[data-v-8231a1c9]{align-items:center;display:flex;justify-content:center;margin-top:120px;width:100%}.search .n-input .n-input__input-el[data-v-8231a1c9]{height:50px!important}.nav-search .n-input[data-v-8231a1c9]{height:50px;width:42%}";

const dynav_vue_vue_type_style_index_0_lang = ".nav-icon{height:80px;width:80px}.nav-icon .n-image{border-radius:50%;display:flex;height:100px;justify-content:center}.n-input .n-input__input-el{height:50px}.nav-node{margin-top:30px}.footer-center,.nav-node{align-items:center;display:flex;justify-content:center}.footer-center{flex:1;height:100%}.n-layout-content{height:100%}.n-layout-footer{align-items:center;bottom:0;display:flex;height:60px;justify-content:center;position:fixed;width:100%}.n-layout .n-layout-scroll-container{overflow:hidden}";

const entryStyles_9e7d9049 = [Components_vue_vue_type_style_index_0_scoped_bf4ccf1f_lang, InputSearch_vue_vue_type_style_index_0_scoped_8231a1c9_lang, dynav_vue_vue_type_style_index_0_lang];

export { entryStyles_9e7d9049 as default };
//# sourceMappingURL=entry-styles.9e7d9049.mjs.map
